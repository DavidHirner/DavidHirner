package Business;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.util.converter.LocalDateStringConverter;

import java.time.LocalDate;
import java.time.Year;

public class Person {
    private SimpleStringProperty firstName;
    private SimpleStringProperty lastName;
    private SimpleStringProperty socialSecurityNumber;
    private SimpleObjectProperty<LocalDate> birthday;
    private SimpleStringProperty street;
    private SimpleStringProperty city;
    private SimpleStringProperty state;
    private SimpleStringProperty gender;
    private SimpleIntegerProperty numberOfChildren;
    private SimpleStringProperty favPizza;

    public Person(String firstName, String lastName, String socialSecurityNumber, LocalDate birthday, String street, String city, String state, String gender, Integer numberOfChildren, String favPizza) {
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);
        this.socialSecurityNumber = new SimpleStringProperty(socialSecurityNumber);
        this.birthday = new SimpleObjectProperty<>(birthday);
        this.street = new SimpleStringProperty(street);
        this.city = new SimpleStringProperty(city);
        this.state = new SimpleStringProperty(state);
        this.gender = new SimpleStringProperty(gender);
        this.numberOfChildren = new SimpleIntegerProperty(numberOfChildren);
        this.favPizza = new SimpleStringProperty(favPizza);
    }
    public Person(){
        this.firstName = new SimpleStringProperty("Lukass");
        this.lastName = new SimpleStringProperty("Bauer");
        this.socialSecurityNumber = new SimpleStringProperty("1234 56789");
        this.birthday = new SimpleObjectProperty<>(LocalDate.parse("2020-12-31"));
        this.street = new SimpleStringProperty("Lederergasse 3");
        this.city = new SimpleStringProperty("Vienna");
        this.state = new SimpleStringProperty("Austria");
        this.gender = new SimpleStringProperty("male");
        this.numberOfChildren = new SimpleIntegerProperty(12);
        this.favPizza = new SimpleStringProperty("Salami");
    }

    public String getFirstName() {
        return firstName.get();
    }

    public SimpleStringProperty firstNameProperty() {
        return firstName;
    }

    public String getLastName() {
        return lastName.get();
    }

    public SimpleStringProperty lastNameProperty() {
        return lastName;
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber.get();
    }

    public SimpleStringProperty socialSecurityNumberProperty() {
        return socialSecurityNumber;
    }

    public LocalDate getBirthday() {
        return birthday.get();
    }

    public void setGender(String gender) {
        if(gender != null && gender.length() > 0)
            this.gender.set(gender);
        else
            throw new Error("Input is null or length is smaller than 0");
    }

    public SimpleObjectProperty<LocalDate> birthdayProperty(){
        return birthday;
    }

    public String getStreet() {
        return street.get();
    }

    public SimpleStringProperty streetProperty() {
        return street;
    }

    public String getCity() {
        return city.get();
    }

    public SimpleStringProperty cityProperty() {
        return city;
    }

    public String getState() {
        return state.get();
    }

    public SimpleStringProperty stateProperty() {
        return state;
    }

    public String getGender() {
        return gender.get();
    }

    public SimpleStringProperty genderProperty() {
        return gender;
    }

    public int getNumberOfChildren() {
        return numberOfChildren.get();
    }

    public SimpleIntegerProperty numberOfChildrenProperty() {
        return numberOfChildren;
    }

    public String getFavPizza() {
        return favPizza.get();
    }

    public SimpleStringProperty favPizzaProperty() {
        return favPizza;
    }
    @Override
    public String toString() {
        return getFirstName() + ";" + getLastName() + ";" + getSocialSecurityNumber() + ";" + getBirthday() + ";" + getStreet() + ";" + getCity() + ";" + getState() + ";" + getGender() + ";" + getNumberOfChildren() + ";" + getFavPizza() + ";";
    }
}
