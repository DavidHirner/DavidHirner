package Business;

import javafx.scene.control.TextFormatter;
import javafx.util.StringConverter;

import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

public class SocialSecurityNumberTextField extends PatternTextField{
    int maxLength;
    public SocialSecurityNumberTextField(String regex, String defaultVal, int maxLength) {
        super(regex, defaultVal);
        this.maxLength = maxLength;
    }

    @Override
    public void filter() {
        setTextFormatter(new TextFormatter<String>(new StringConverter<String>() {
            @Override
            public String toString(String s) {
                return s;
            }

            @Override
            public String fromString(String s) {
                if (s != null && s.length() > 0) {
                    return s;
                }
                return defaultVal;
            }
        }, defaultVal, new UnaryOperator<TextFormatter.Change>() {
            @Override
            public TextFormatter.Change apply(TextFormatter.Change change) {
                String changeWithoutSpace = change.getControlNewText().replace(" ", "");
                if (Pattern.matches(regex, change.getControlNewText()) && changeWithoutSpace.length() <= maxLength) {
                    return change;
                }
                return null;
            }
        }));
    }
}
