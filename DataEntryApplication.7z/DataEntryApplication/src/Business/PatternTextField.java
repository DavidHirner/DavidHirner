package Business;
import javafx.beans.property.Property;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.util.StringConverter;

import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

public class PatternTextField extends TextField {
    String regex;
    String defaultVal;
    public PatternTextField(String regex, String defaultVal) {
        this.regex = regex;
        this.defaultVal = defaultVal;
    }

        public void filter(){
            setTextFormatter(new TextFormatter<String>(new StringConverter<String>() {
                @Override
                public String toString(String s) {
                    return s;
                }

                @Override
                public String fromString(String s) {
                    if (s != null && s.length() > 0) {
                        return s;
                    }
                    return defaultVal;
                }
            }, defaultVal, new UnaryOperator<TextFormatter.Change>() {
                @Override
                public TextFormatter.Change apply(TextFormatter.Change change) {
                    if (Pattern.matches(regex, change.getControlNewText())) {
                        return change;
                    }
                    return null;
                }
            }));
        }

    public void bindBidirectional(Property<String> stringProperty){
        this.textProperty().bindBidirectional(stringProperty);
    }
}