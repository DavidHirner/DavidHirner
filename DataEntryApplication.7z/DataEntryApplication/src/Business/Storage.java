package Business;

import javafx.util.converter.LocalDateStringConverter;

import java.io.*;
import java.time.LocalDate;

public class Storage {



    public void save(Person toSave, File f){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(f.getAbsolutePath()))){
            writer.write(toSave.toString());
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    public Person load(File filename){
        Person person = null;
        try{
            BufferedReader reader = new BufferedReader(new FileReader(filename.getAbsolutePath()));
            String dataLine = reader.readLine();
            String[] data =  dataLine.split(";");
            person = new Person(data[0], data[1], data[2], LocalDate.parse(data[3]) , data[4], data[5], data[6], data[7], Integer.parseInt(data[8]), data[9]);
        } catch (IOException e){
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }

        return person;
    }
}
