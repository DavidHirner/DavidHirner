package Presentation;

import Business.PatternTextField;
import Business.Person;
import Business.SocialSecurityNumberTextField;
import Business.Storage;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.converter.LocalDateStringConverter;
import jdk.nashorn.internal.runtime.regexp.joni.Warnings;

import javax.swing.*;
import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

public class Main extends Application {
    Storage storage;
    Person person;
    File file;
        @Override
    public void start(Stage primaryStage) throws Exception{
        VBox root = new VBox();
        MenuBar menuBar = menu(root);
       storage = new Storage();
       file = null;
       person = null;
        root.getChildren().addAll(menuBar);
        Scene mainScene = new Scene(root, 400, 450);
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }


    public HashMap<String, VBox> personEntryForm(){

        Label firstNameL = new Label("First Name: ");
        PatternTextField firstName = new PatternTextField("[a-zA-Z]*", "Lukas");
        firstName.filter();
        Label lastNameL = new Label("Last Name: ");
        PatternTextField lastName = new PatternTextField("[a-zA-Z]*", "Bauer");
        lastName.filter();
        Label socialSecurityNumberL = new Label("Social Security Number: ");
        SocialSecurityNumberTextField socialSecurityNumber = new SocialSecurityNumberTextField("\\d{0,4}[ ]{0,1}\\d{0,6}", "1234 080808", 10);
        socialSecurityNumber.filter();
        Label birthdayL = new Label("Birthday: ");
        DatePicker birthday = new DatePicker();
        LocalDateStringConverter ldc = new LocalDateStringConverter();
        birthday.setConverter(ldc);
        Label streetL = new Label("Street: ");
        PatternTextField street = new PatternTextField("[a-zA-Z]*[ ]{0,1}\\d{0,4}", "Street 1");
        street.filter();
        Label cityL = new Label("City: ");
        PatternTextField city = new PatternTextField("[a-zA-Z]*", "Vienna");
        city.filter();
        Label stateL = new Label("State: ");
        ComboBox<String> state = new ComboBox<String>();
        state.getItems().addAll("Austria", "Germany", "Switzerland");
        state.setValue("Select a state");
        Label genderL = new Label("Gender: ");
        HBox root2 = new HBox();
        RadioButton male = new RadioButton("male ");
        RadioButton female = new RadioButton("female ");
        RadioButton other = new RadioButton("other ");
        final ToggleGroup group = new ToggleGroup();
        male.setToggleGroup(group);
        female.setToggleGroup(group);
        other.setToggleGroup(group);
        root2.getChildren().addAll(male, female, other);
        Label numberOfChildrenL = new Label("Number of Children: ");
        Spinner numberOfChildren = new Spinner<Integer>(0, 5734, 2);
        Label favPizzaL = new Label("Favourite pizza: ");
        ObservableList<String> pizzas = FXCollections.observableArrayList("Margerita", "Quattro Stagioni", "Marinara", "Spinachi", "Salami", "Quattro Formaggi", "Hawai", "Provinciale", "Vegizzl", "Proscciuto");
        Spinner favPizza = new Spinner(pizzas);

        firstName.bindBidirectional(person.firstNameProperty());
        lastName.bindBidirectional(person.lastNameProperty());
        socialSecurityNumber.bindBidirectional(person.socialSecurityNumberProperty());
        birthday.valueProperty().bindBidirectional(person.birthdayProperty());
        street.bindBidirectional(person.streetProperty());
        city.bindBidirectional(person.cityProperty());
        state.valueProperty().bindBidirectional(person.stateProperty());



        group.selectedToggleProperty().addListener((observable, oldValue, newValue) ->{
            if(male.isSelected()){
                person.setGender("male");
            }
            else if(female.isSelected()){
                person.setGender("female");
            }
            else{
                person.setGender("other");
            }
        });
        if(person.getGender().equals("male")){
            male.setSelected(true);
        }
        else if(person.getGender().equals("female")){
            female.setSelected(true);
        }
        else{
            other.setSelected(true);
        }



        numberOfChildren.getValueFactory().valueProperty().bindBidirectional(person.numberOfChildrenProperty());
        favPizza.getValueFactory().valueProperty().bindBidirectional(person.favPizzaProperty());


        VBox firstnameBox = new VBox(5, firstNameL, firstName);
        VBox lastnameBox = new VBox(5, lastNameL, lastName);
        VBox socialSNBox = new VBox(5, socialSecurityNumberL, socialSecurityNumber);
        VBox birthdayBox = new VBox(5, birthdayL, birthday);
        VBox streetBox = new VBox(5, streetL, street);
        VBox cityBox = new VBox(5, cityL, city);
        VBox stateBox = new VBox(5, stateL, state);
        VBox genderBox = new VBox(5, genderL, root2);
        VBox nOfChildrenBox = new VBox(5, numberOfChildrenL, numberOfChildren);
        VBox pizzaBox = new VBox(5, favPizzaL, favPizza);

        HashMap<String, VBox> vBoxes = new HashMap<>();
        vBoxes.put("First Name", firstnameBox); vBoxes.put("Last Name", lastnameBox); vBoxes.put("Social security Number", socialSNBox);
        vBoxes.put("Birthday", birthdayBox); vBoxes.put("Street", streetBox); vBoxes.put("City", cityBox); vBoxes.put("State", stateBox);
        vBoxes.put("Gender", genderBox); vBoxes.put("Number of children", nOfChildrenBox); vBoxes.put("Fav pizza", pizzaBox);


        return vBoxes;
    }

    public MenuBar menu(VBox root){
            MenuItem newItem = new MenuItem("New...");
            newItem.setOnAction(actionEvent -> {
                person = new Person();
                if(root.getChildren().size() > 5) {
                    root.getChildren().remove(1, 11);
                }
                showIt(root);
            });

            MenuItem loadItem = new MenuItem("Load...");
            loadItem.setOnAction(actionEvent -> {
                FileChooser chooser = new FileChooser();
                File file = chooser.showOpenDialog(null);
                person = storage.load(file);
                root.getChildren().remove(1, 11);
                showIt(root);
            });

            MenuItem saveItem = new MenuItem("Save...");
            saveItem.setOnAction(actionEvent -> {
                if(file == null) {
                    File defaultFile = new File("D:\\Users\\david\\Documents\\" + person.getSocialSecurityNumber() + ".csv");
                    storage.save(person, defaultFile);
                }
                else
                    storage.save(person, file);
            });

            MenuItem saveAsItem = new MenuItem("Save As...");
            saveAsItem.setOnAction(actionEvent -> {
            FileChooser chooser = new FileChooser();
            file = chooser.showSaveDialog(null);
            storage.save(person, file);
        });

            MenuItem exitItem = new MenuItem("Exit...");
            exitItem.setOnAction(actionEvent -> {
                Alert exit = new Alert(Alert.AlertType.WARNING);
                exit.setTitle("Exit");
                exit.setHeaderText("You sure bout that?");
                ButtonType no = new ButtonType("no");
                ButtonType yes = new ButtonType("yes");
                exit.getButtonTypes().setAll(yes, no);
                Optional<ButtonType> result = exit.showAndWait();
                if(result.get() == yes) {
                    System.exit(0);
                }
            });

            Menu file = new Menu("File");
            MenuBar menuBar = new MenuBar();

            file.getItems().addAll(newItem, loadItem, saveItem, saveAsItem, exitItem);
            menuBar.getMenus().addAll(file);
            return menuBar;
    }

    public void showIt(VBox root){
        HashMap<String, VBox> vBoxes = personEntryForm();
        VBox firstNameBox = vBoxes.get("First Name");
        VBox lastNameBox = vBoxes.get("Last Name");
        VBox socialSecurityNumberBox = vBoxes.get("Social security Number");
        VBox birthdayBox = vBoxes.get("Birthday");
        VBox streetBox = vBoxes.get("Street");
        VBox cityBox = vBoxes.get("City");
        VBox stateBox = vBoxes.get("State");
        VBox genderBox = vBoxes.get("Gender");
        VBox numberOfChildrenBox = vBoxes.get("Number of children");
        VBox favPizzaBox = vBoxes.get("Fav pizza");
        root.getChildren().addAll(firstNameBox, lastNameBox, socialSecurityNumberBox, birthdayBox, streetBox, cityBox, stateBox, genderBox, numberOfChildrenBox, favPizzaBox);
        }
}
